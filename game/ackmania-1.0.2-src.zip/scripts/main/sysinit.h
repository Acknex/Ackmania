#ifndef sysinit_h
#define sysinit_h

void doSysInit();

#include "sysinit.c"

#endif /* sysinit_h */
