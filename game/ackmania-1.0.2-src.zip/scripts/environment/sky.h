#ifndef sky_h
#define sky_h

void skychange ();
void skychange (float s);

var sky_active;

#include "sky.c"

#endif /* sky_h */