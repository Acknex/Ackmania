#ifndef environment_h
#define environment_h

#include "sky.h"

void environment_load (char* str, float skyspeed);

#include "environment.c"

#endif /* environment_h */
