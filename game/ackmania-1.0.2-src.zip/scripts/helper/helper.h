#ifndef helper_h
#define helper_h

void place_on_floor(ENTITY* _ent);

var get_nearest_path_point(ENTITY* ent, char* pathname);

#include "helper.c"

#endif /*helper_h*/