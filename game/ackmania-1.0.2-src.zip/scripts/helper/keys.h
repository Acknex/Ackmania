/*
 *******************************************************************************
 * keys.h
 * Creation date: 19.07.2014
 * Author:        Firoball
 *
 *******************************************************************************
 * $Date: 2014-07-24 23:40:01 +0200 (Do, 24 Jul 2014) $
 * $Revision: 396 $
 * $Author: Firoball $
 *
 *******************************************************************************
 * Description
 *
 * definition script for key bindings
 *
 * Comments
 * 
 * for short descriptions see comments in this file
 *
 *******************************************************************************
 */

#ifndef KEYS_H
#define KEYS_H


#include "keys.c"

#endif