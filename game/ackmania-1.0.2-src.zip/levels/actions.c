// race kart position (!)
// skill1 = id (1...)
action ac_race_kart_pos () { wait(1); }
action a4_cube() { wait(1); }
action item() { wait(1); }
action spikes() { wait(1); }