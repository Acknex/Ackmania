#ifndef _TRIGGER_H_
#define _TRIGGER_H_

action trigger_wall();
action trigger_visible();

#include "trigger.c"

#endif