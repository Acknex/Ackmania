#ifndef _GAME_H_
#define _GAME_H_

void game_start(void);
void game_restart(void);

var vGameMusicHandle = 0;

#include "game.c"

#endif // #ifndef _GAME_H_