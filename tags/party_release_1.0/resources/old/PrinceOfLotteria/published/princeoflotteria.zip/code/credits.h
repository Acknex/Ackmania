#ifndef _CREDITS_H_
#define _CREDITS_H_

/**
 * Starts the credits.
 */
void credits_run(void);

#endif // #ifndef _CREDITS_H_